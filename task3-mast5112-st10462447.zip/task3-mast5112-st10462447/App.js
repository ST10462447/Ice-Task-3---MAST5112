import React, { useState } from 'react';
import { StyleSheet, 
         Text, 
         View, 
         Button 
        } from 'react-native';
import HomeScreen from './HomeScreen';
import GameScreen from './GameScreen';
import ResultScreen from './ResultScreen';

export default function App() {
  const [screen, setScreen] = useState('home');
  const [score, setScore] = useState(0);

  const handleStartGame = () => {
    setScreen('game');
    setScore(0);
  };

  const handleGameOver = (finalScore: number) => {
    setScore(finalScore);
    setScreen('result');
  };

  return (
    <View style={styles.container}>
      {screen === 'home' && <HomeScreen onStartGame={handleStartGame} />}
      {screen === 'game' && <GameScreen onGameOver={handleGameOver} />}
      {screen === 'result' && <ResultScreen score={score} onRestart={handleStartGame} />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
});
