import React, { useState, useEffect } from 'react';
import { StyleSheet, 
         Text, 
         View, 
         TouchableOpacity 
        } from 'react-native';

interface GameScreenProps {
  onGameOver: (score: number) => void;
}

const cards = [
  { id: 1, name: 'plastic', src: 'plastic.jpg' },
  { id: 2, name: 'paper', src: 'paper.jpg' },
  { id: 3, name: 'glass', src: 'glass.jpg' },
  { id: 4, name: 'metal', src: 'metal.jpg' },
  { id: 5, name: 'plastic', src: 'plastic.jpg' },
  { id: 6, name: 'paper', src: 'paper.jpg' },
  { id: 7, name: 'glass', src: 'glass.jpg' },
  { id: 8, name: 'metal', src: 'metal.jpg' },
];

const GameScreen: React.FC<GameScreenProps> = ({ onGameOver }) => {
  const [matchedPairs, setMatchedPairs] = useState<string[]>([]);
  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime <= 1) {
          clearInterval(timer);
          onGameOver(score);
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [score, onGameOver]);

  const handleCardPress = (id: number, name: string) => {
    if (selectedCards.length === 0) {
      setSelectedCards([id]);
    } else {
      if (selectedCards[0] !== id) {
        setSelectedCards([...selectedCards, id]);
        if (cards[selectedCards[0] - 1].name === name) {
          setMatchedPairs([...matchedPairs, name]);
          setScore((prevScore) => prevScore + 10);
        } else {
          setTimeout(() => setSelectedCards([]), 1000);
        }
      }
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.timer}>Time Left: {timeLeft}s</Text>
      <Text style={styles.score}>Score: {score}</Text>
      <View style={styles.grid}>
        {cards.map((card, index) => (
          <TouchableOpacity
            key={index}
            style={[
              styles.card,
              matchedPairs.includes(card.name) || selectedCards.includes(card.id)
                ? styles.cardFlipped
                : {},
            ]}
            onPress={() => handleCardPress(card.id, card.name)}
            disabled={matchedPairs.includes(card.name)}
          >
            <Text>{matchedPairs.includes(card.name) || selectedCards.includes(card.id) ? card.name : '?'}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  timer: {
    fontSize: 20,
    marginBottom: 10,
  },
  score: {
    fontSize: 20,
    marginBottom: 20,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  card: {
    width: 80,
    height: 80,
    margin: 10,
    backgroundColor: '#ccc',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
  },
  cardFlipped: {
    backgroundColor: '#4CAF50',
  },
});

export default GameScreen;
