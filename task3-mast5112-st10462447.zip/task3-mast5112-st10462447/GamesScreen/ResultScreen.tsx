import React from 'react';
import { StyleSheet, 
         Text, 
         View, 
         Button 
        } from 'react-native';

interface ResultScreenProps {
  score: number;
  onRestart: () => void;
}

const ResultScreen: React.FC<ResultScreenProps> = ({ score, onRestart }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Recycling Points: {score}</Text>
      <Button title="Recycle More" onPress={onRestart} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
});

export default ResultScreen;
